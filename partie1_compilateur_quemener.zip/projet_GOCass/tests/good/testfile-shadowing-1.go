package main
func f(x bool) { { x := 1; x++ } }
func main() { f(true) }
