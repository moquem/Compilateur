package main
import "fmt"
func main() {
	x, _ := 3, 1
	y, _ := 4, 2
	fmt.Print(x+y, "\n");
}
