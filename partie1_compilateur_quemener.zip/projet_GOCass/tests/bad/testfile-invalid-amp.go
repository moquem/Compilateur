package main

func foo () {}

func main () {
	&3
}
