package main

type  Booksabc struct {
    title string
    author string
}


type Booksabc struct {
    title string
    author string
}

func main() {}
