package main

func foo () { return 3}

func main () {}
