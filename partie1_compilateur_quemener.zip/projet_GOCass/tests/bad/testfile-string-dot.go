package main

func main() { "test".x }
