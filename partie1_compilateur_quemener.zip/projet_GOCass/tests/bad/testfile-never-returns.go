package main

func foo () int {}

func main () {}
