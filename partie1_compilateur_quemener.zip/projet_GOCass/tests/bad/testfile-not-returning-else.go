package main

func foo () int { if (3 > 2) {return 3} }

func main () {}
