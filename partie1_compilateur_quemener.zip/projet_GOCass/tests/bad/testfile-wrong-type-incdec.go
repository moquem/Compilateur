package main

func main() {"a"++;}
