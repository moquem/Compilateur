package main

type T struct { x int }

func main() {
	var a = new(T)
	a.x = 5
	a.y = 3
}
