package main

type T struct {x int}

func main () {
	new(T)
	new(S)
}
