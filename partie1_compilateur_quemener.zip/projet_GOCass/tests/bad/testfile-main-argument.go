package main

func main(x int) {}
