package main

func main() {
	var a int
}
