package main

func foo () int {for (3 >= 2) {return 2} }

func main () {}
