package main
func main() { 1 = 2 }
