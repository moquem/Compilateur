package main

func foo (x int) {}

func main() {foo(2); fooo(5)}
