package main
func foo() int { return 42 }
