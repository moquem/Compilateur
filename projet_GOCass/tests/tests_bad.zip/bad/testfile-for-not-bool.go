package main

func main () { for ("test") {} }
